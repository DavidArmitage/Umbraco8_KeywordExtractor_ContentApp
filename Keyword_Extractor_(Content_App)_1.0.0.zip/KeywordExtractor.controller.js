﻿
angular.module("umbraco")
    .controller("My.KeywordExtractor", function ($http, $scope, editorState, contentResource) {

        var vm = this;
        vm.CurrentNodeId = editorState.current.id;
        vm.CurrentNodeAlias = editorState.current.contentTypeAlias;
        vm.FullContent = '';
        vm.IsTestMode = false;
        vm.Loading = false;
        vm.ShowSuccess = false;
        vm.Language = SetLanguage(editorState);
        vm.EditorState = editorState;

        $http({
            method: "GET",
            url: "/Umbraco/KeywordExtractor/KeywordExtractor/IsTestMode"
        }).then(function mySuccess(response) {
            vm.IsTestMode = response.data;
        });

        $scope.ExtractKeywords = function () {

            vm.FullContent = '';
            var currentPage = contentResource.getById(vm.CurrentNodeId).then(function (node) {
                var editorState = vm.EditorState.current;
                var variants = editorState.variants;
                if (variants) {
                    var variantIndex;
                    for (variantIndex = 0; variantIndex < variants.length; ++variantIndex) {
                        if (variants[variantIndex].active == true) {
                            var tabs = variants[variantIndex].tabs;
                            if (tabs) {
                                var tabIndex;
                                for (tabIndex = 0; tabIndex < tabs.length; ++tabIndex) {
                                    var properties = node.variants[variantIndex].tabs[tabIndex].properties;
                                    var propertyIndex;
                                    for (propertyIndex = 0; propertyIndex < properties.length; ++propertyIndex) {
                                        if (properties[propertyIndex].editor == "Umbraco.Grid") {
                                            var gridWords = $scope.UmbracoGridExtract(properties[propertyIndex]);
                                            vm.FullContent = vm.FullContent + gridWords;
                                        }
                                        else {
                                            var words = properties[propertyIndex].value + ' ';
                                            vm.FullContent = vm.FullContent + words;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                vm.Loading = true;
                vm.ShowResults = false;
                vm.ErrorMessage = '';
                var url = "/Umbraco/KeywordExtractor/KeywordExtractor/ExtractKeywords";

                $http({
                    method: "POST",
                    url: url,
                    data: {
                        FullContent: vm.FullContent,
                        Language: vm.Language
                    },
                }).then(function successCallback(response) {
                    vm.Loading = false;
                    vm.ShowResults = true;
                    var data = angular.fromJson(response.data);
                    vm.Entities = data.Entities;
                    vm.Concepts = data.Concepts;
                    vm.QuantityExpressions = data.QuantityExpressions;
                    vm.MoneyExpressions = data.MoneyExpressions;
                    vm.TimeExpressions = data.TimeExpressions;
                    vm.OtherExpressions = data.OtherExpressions;
                    vm.Quotations = data.Quotations;
                    vm.ErrorMessage = data.ErrorMessage;

                }, function errorCallback() {
                    vm.Loading = false;
                    vm.ErrorMessage = "Sorry there was a generic error. If this continues to happen please notify support for a fix.";
                });
            });
        };

        $scope.UmbracoGridExtract = function (property) {

            var sectionIndex;
            var sections = property.value.sections;
            var gridContent = '';

            for (sectionIndex = 0; sectionIndex < sections.length; ++sectionIndex) {
                var rowsIndex;
                var rows = property.value.sections[sectionIndex].rows;

                for (rowsIndex = 0; rowsIndex < rows.length; ++rowsIndex) {
                    var areasIndex;
                    var areas = property.value.sections[sectionIndex].rows[rowsIndex].areas;

                    for (areasIndex = 0; areasIndex < areas.length; ++areasIndex) {
                        var controlsIndex;
                        var controls = property.value.sections[sectionIndex].rows[rowsIndex].areas[areasIndex].controls;

                        for (controlsIndex = 0; controlsIndex < controls.length; ++controlsIndex) {
                            var value = property.value.sections[sectionIndex].rows[rowsIndex].areas[areasIndex].controls[controlsIndex].value;
                            gridContent = gridContent + " " + value;
                        }
                    }
                }
            }

            return gridContent;
        };
    });

function SetLanguage (editorState) {
    var culture = "";
    angular.forEach(editorState.current.variants, function (value) {
        if (value.active == true) {
            if (value.language) {
                culture = value.language.culture;
            }
        }
    });

    if (!culture) {
        culture = "en";
    }
    else {
        if (culture.includes("-")) {
            culture = culture.substring(0, culture.indexOf("-"));
        }
    }

    var supportedCultures = ["en", "es", "it", "fr", "pt"];

    if (supportedCultures.indexOf(culture) !== -1) {
        return culture;
    }

    return "en";
};

